#pragma once
#ifndef Controle_H
#define Controle_H
//-----------------------------------------------------------------------
#include "InterfaceUsuario.h"
#include "MegaSena.h"
#include "LotoFacil.h"

class Controle
{
private:

public:
	Controle();
	~Controle();
	void controlarExecucao(void);
};
//-----------------------------------------------------------------------
#endif
