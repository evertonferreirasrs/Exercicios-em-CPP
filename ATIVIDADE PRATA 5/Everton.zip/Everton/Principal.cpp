#include "Controle.h"

int main(int argc, char * argv[])
{
	Controle c;

	c.controlarExecucao();

	return 0;
}