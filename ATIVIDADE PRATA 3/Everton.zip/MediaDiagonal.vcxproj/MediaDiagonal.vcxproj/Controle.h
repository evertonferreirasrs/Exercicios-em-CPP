#include <iostream>
using namespace std;
#include <string>

#include "InterfaceUsuario.h"
#include "MediaDiagonalMatriz.h"

//---------------------------------------------------------------------------------
class Controle
{
private:

public:
	Controle();
	~Controle();
	void GerenciarExecucao(void);
};

