#include <iostream>
using namespace std;
#include <string>

//---------------------------------------------------------------------------------
class InterfaceUsuario
{
private:

public:
	InterfaceUsuario();
	~InterfaceUsuario();
	void exibirMatriz(float [10][10]);
	void exibirResultado(float);
};

