#include <iostream>
using namespace std;
#include <string>

#include "InterfaceUsuario.h"
#include "SegmentoDeReta.h"

class Controle
{
private:
public:
	Controle();
	~Controle();
	void gerenciarExecucao(void);
};